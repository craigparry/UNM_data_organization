#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

struct ListNode * sortedHelper(struct ListNode* newNode, struct ListNode* nextNode, struct ListNode* head);
int removeHelper(struct ListNode* nextNode, int data, struct ListNode** headRef);
void freeListHelper(struct ListNode* nextNode, struct ListNode* head);
void printHelper(struct ListNode* nextNode, struct ListNode* head);
int lengthHelper(struct ListNode* nextNode, struct ListNode* head);
void reverseHelper(struct ListNode* workNode, struct ListNode* prevNode,struct ListNode** headRef);


/* Alloc a new node with given data. */
struct ListNode * createNode(int data)
{
  struct ListNode* temp;
  temp = malloc(sizeof(struct ListNode)); 
  temp->data = data;
  temp->next = NULL;
  temp->prev = NULL;
  return temp;
  // CHANGE THE REST TO CHECK FOR NULL!
}

/* Insert data at appropriate place in a sorted list, return new list head. */
struct ListNode * insertSorted(struct ListNode* head, int data)
{ 

  struct ListNode* temp;
  temp = createNode(data);

  if(head == NULL) 
  { 
    return temp;
  } 

  if(head->next ==NULL)
  {
      if(temp->data < head->data)
      { 
        temp->next = head;
        temp->prev = head;
        head->prev = temp;
        head->next = temp;
        return temp;
      }
      else
      {
        temp->next = head;
        temp->prev = head;
        head->prev = temp;
        head->next = temp;
        return head;
      }
  }
  //if(temp->next == temp) return temp;
  /*if  data is less than made node*/
  if(temp->data <= head->data)
  {
    /*if data is smaller since dealing with ints
    make the new node the head*/
    
    temp->next = head;
    temp->prev = head->prev;
    head->prev->next = temp;
    head->prev = temp;
    return temp;
  } 
 // if(temp->data == 22)
 //    {
 //      printf("here\n");
 //    }
 //    printf("broken length %d\n",listLength(head)); 
  /*checking for lists that had all items removed enp should be 
    equal to the head, but contain nothing*/
  // need help here
  // if(data == 22)
  // {
  //   printf("head next %p\n",head->next);
  //   printf("head%p\n",head);
  // }

  // if(head->next == head)
  // { 
  //   if(temp->data == 22)
  //   {
  //     printf("broken here\n");
  //   }
  //   temp->prev = head;
  //   temp ->next = head;
  //   head->next = temp;
  //   head ->prev = temp;
    
    
  //   return head;
  // }
 // if(temp->data == 22)
 //    {
 //      printf("goes here\n");
 //    }
  // /*if not less than and weve reached the end*/
  // if(head->next == head)
  // {
    
  //   temp->prev = head;
  //   temp->next = head->next;
  //   head->next = temp;
   
  //   return head;
  // }

  /*not the end of the list and number is not greater than*/
  
  //not no more huauau 
    // printf("broke here\n");
    sortedHelper(temp,head->next, head);
    return head;
  
}

/*recursive helper to traverse the structure return origninal head
counts the amount of times the function is called giving the index*/

struct ListNode * sortedHelper(struct ListNode* newNode, struct ListNode* nextNode, struct ListNode* head)
{
  if(nextNode == head)
  {
    newNode->next = nextNode;
    newNode->prev = nextNode->prev;
    nextNode->prev->next= newNode;
    nextNode->prev= newNode; 
    // nextNode->next =newNode;
    
    return head;
  }
  if(newNode->data < nextNode->data)
  {
    // printf("break here\n");
    /*connect new node to node prev and next */
    newNode->next = nextNode;
    newNode->prev = nextNode->prev;
    /*connect prev not to newNode*/
    newNode->prev->next = newNode;
    /*connect next node to newNode*/
    nextNode->prev = newNode;
    return head;
  }
  
  
  return sortedHelper(newNode,nextNode->next, head);
  
}


/* Remove data from list pointed to by headRef, changing head if necessary.
 * Make no assumptions as to whether the list is sorted.
 * Memory for removed node should be freed.
 * Return 1 if data was present, 0 if not found. */
int removeItem(struct ListNode** headRef, int data)
{ 
  struct ListNode * temp;  
  temp = *headRef;
  /*zero if list doesn't exist*/
  if(temp == NULL) return 0;

  /*if data exists at first node*/
  if(temp->data == data)
  { 
    if(temp->next == temp)
    {
      *headRef = NULL;
    } 
    else
    {
      *headRef= temp->next;
      temp->prev->next = temp->next;
      temp->next->prev = temp->prev;
    }
    
    free(temp);
    return 1;
  } 
  /*if the first node is also the endpointer data not present*/
  if(temp->next == NULL) 
  {
    return 0;
  }
  /*more nodes and data not found call the helper*/
  return removeHelper(temp->next,data, headRef);
}
/*return 1 if data was found return zero if data is not found*/
int removeHelper(struct ListNode* nextNode, int data, struct ListNode** headRef)
{

  if(*headRef == nextNode) return 0; 
  if(nextNode-> data == data)
  {
    nextNode->prev->next = nextNode->next;
    nextNode->next->prev = nextNode->prev;
    free(nextNode);
    return 1; 
  } 
  return removeHelper(nextNode->next, data, headRef);
}

/* Treat list as a stack. (LIFO - last in, first out)
 * Insert data at head of list, return new list head. */
struct ListNode * pushStack(struct ListNode* head, int data)
{
  struct ListNode * temp = createNode(data);

  if(head == NULL)
  {
    return temp;
  } 
  //make sure this works with NULL lists!!! creating new lists 
  if(head->next == NULL)
  {
    temp->next = head;
    temp->prev = head;
    head->next = temp;
    head->prev = temp;
  }
  else
  {
    temp->next = head;
    temp->prev = head->prev;
    head->prev->next = temp;
    head->prev = temp;
  }
  return temp;
}

/* Treat list as a stack. (LIFO - last in, first out)
 * Remove and return data from head of non-empty list, changing head.
 * Memory for removed node should be freed. */
int popStack(struct ListNode** headRef)
{
  /*need to check my syntax, but want to access the first thing pointed 
  to by headRef, then point to the first node of that*/

  //make sure it doesn't try to pop a NULL stack
  if(*headRef == NULL) return -1; 

  struct ListNode * temp; 
  int tempData; 
  // printf("here\n");


  temp = *headRef; 

  if(temp->next == NULL)
    {
      tempData = temp->data;
      *headRef = NULL;
      free(temp);
      return tempData;
    }

  temp->next->prev = temp->prev;
  temp->prev->next = temp->next;
  tempData = temp->data;
  *headRef = temp->next;
  
  /*freeing what temp is pointing to*/
  free(temp);
  

  return tempData;
}

/* Return length of the list. */
int listLength(struct ListNode* head)
{   
    // make sure it doesn't try to count a NULL list 
  // how do I make this work!!!
  if(head->next == head)
  { 
    return 1; 
  }
  else
  { 
    return 1+lengthHelper(head->next,head);
  }
}

int lengthHelper(struct ListNode* nextNode, struct ListNode* head)
{
  if(nextNode == head)
  {
    if(nextNode->data == 22)
    {
      // printf("made it\n");
    }
    return 0;
  } 
  else return 1+lengthHelper(nextNode->next,head);
}

/* Print list data on single line, separating values with a comma and
 * a space and ending with newline. */
void printList(struct ListNode* head)
{
  /*need to use a helper function because this will never be null 
in a doubly linkedlist*/
  if(head == NULL) return;
  // make sure it checks for NULL gosh 
  // printf("here\n");
  if(head->next == NULL)
    {
      // printf("reached\n");
      printf("%d\n",head->data);
    }
  else
    {
      // printf("reached \n");
      printf("%d, ",head->data);
      // printf("reached2 \n");
      printHelper(head->next, head);
    }
}

void printHelper(struct ListNode* nextNode, struct ListNode* head)
{
  if(nextNode->next == head)
  { 
    // printf("reached3 \n");
    printf("%d\n",nextNode->data);
  } 

  else 
    {
      // printf("reached4 \n");
      printf("%d, ",nextNode->data);
      printHelper(nextNode->next, head);
    }
}

/* Free memory used by the list. */
void freeList(struct ListNode* head)
{
  /*not tested yet, but needs to be run through valgrind
  to check for leaks*/
 if(head ==NULL) return;

 if(head->next == NULL)
 {
  free(head);
  head =NULL;
  return; 
 } 
 freeListHelper(head->next, head);
 free(head);
 head =NULL;
}

void freeListHelper(struct ListNode* nextNode, struct ListNode* head)
{
  if(nextNode->next == head)
  {
    free(nextNode);
    return;
  }
  freeListHelper(nextNode->next, head);
  free(nextNode);
}
/* Reverse order of elements in the list */
void reverseList(struct ListNode** headRef)
{
  /*bonus point for doing it by just changing pointers */
  // check for NULL list
  struct ListNode* temp;
  temp = *headRef;

  temp->prev = temp->next;
  reverseHelper(temp->next, temp, headRef);
  *headRef = temp->next;
}

void reverseHelper(struct ListNode* workNode, struct ListNode* prevNode,struct ListNode** headRef)
{
  if(workNode != *headRef)
  {
    workNode->prev = workNode->next;
    reverseHelper(workNode->next, workNode,headRef);
    workNode->next = prevNode;
    return;
  }
  else
  {
    workNode->next = prevNode;
    return;
  }

}

// int main()
// {
//   struct ListNode ** LLP;
//   *LLP =insertSorted(*LLP,1);
//   *LLP =insertSorted(*LLP,2);
//   printList(*LLP);
//   *LLP = insertSorted(*LLP,3);
//   printList(*LLP);
//   *LLP = insertSorted(*LLP,5);
//   printList(*LLP);


//   return 0;
// }
// int main()
// {
//   /*testing creation of linked list and using insert sorted
//     tests first node and whether it connects the initail node correctly to 
// the head and to the end of the list when they are initalized at null 
// */int testInt;
//   struct ListNode ** LLP;
//   // struct ListNode * doubleLL = createNode(1);
//   // struct ListNode * doubleLL;
//   // *LLP = doubleLL;
//   *LLP =insertSorted(*LLP,1); // make sure to use the pointer to a pointer so it doesn't get confused 
  
//   if(*LLP == NULL) printf("null\n");
//   testInt = popStack(LLP);
//   if(*LLP == NULL) printf("LLP is null\n");
  
//   /*test if printList is trying to print null */
//   printList(*LLP);
//   printf("test: %d\n",testInt);
//   *LLP = insertSorted(*LLP,1);
//   printList(*LLP);

//   // printf("end %p\n",endp);
//   // endp = doubleLL;
//   insertSorted(*LLP,5);
//   // printf(" %d, %d ",doubleLL->data,doubleLL->next->data);

//   // printf("head %p\n",doubleLL);
//   // printf("end %p\n",endp);
//   testing with print function should return 1,5
//   printList(*LLP); 
//   printf("worked\n");

//   /*testing inserting inbetween*/
//   insertSorted(*LLP,3);
//   /*should print 1,3,5 but broke for now*/
//   printList(*LLP);

//   /*push stack test*/
//   *LLP= pushStack(*LLP,8);
//   /*should print 8,1,3,5*/
//   printList(*LLP);
//   /*it's broken right now, but the problem may be either in my print statement
// or in the insertSorted which I was debuggin before I got to debuggin my pushStack
// */
//   printf("list length: %d\n",listLength(*LLP));

  
//   //should pop the 8 added
//   printf("%d\n", popStack(LLP));
//   // first element should be 1 
//   // printf("%d\n", LLP[0]->data);

//   /*pop and remove from an empty list to check if those break*/

//   // need to make a new list with a pointer to nothing
//   // can check for NULL, but may cause error with valgrind
//   // struct ListNode * pointy;
//   // if(pointy == NULL) printf("is null\n"); 
//   // insertSorted(pointy,3); 
  
//   return 0;
// }

