#include <stdio.h>
#include <stdlib.h>
#include "binarytree.h"
#include "linkedlist.h"
 // #include "linkedlist.c"

void printTreeHelper(struct TreeNode* root);
void dfsHelper(struct TreeNode* root, struct ListNode * stack);

/* Alloc a new node with given data. */
struct TreeNode* createTreeNode(int data)
{
  struct TreeNode* temp;
  temp = malloc(sizeof(struct TreeNode));

  temp->left = NULL;
  temp->right = NULL;
  temp->data = data;

  return temp;
}

/* Print data for inorder tree traversal on single line,
 * separated with spaces, ending with newline. */
void printTree(struct TreeNode* root)
{ /*calling a helper cause it would have been redundant
    to write the same code here with a printline at the end*/
  printTreeHelper(root);
  /*since first node we have to print newline at the end*/
  printf("\n");

}
void printTreeHelper(struct TreeNode* root)
{
  /*if left branch is not null call it*/
  if(root->left !=NULL)
  {
    printTreeHelper(root->left); 
  } 
  /*once left branch has returned to this node print this node*/
  printf("%d ",root->data);
  /*and call the right branch if it is not null*/
  if(root->right!=NULL)
  {
    printTreeHelper(root->right);
  }
}
/* Free memory used by the tree. */
void freeTree(struct TreeNode* root)
{
  /*just wrote this need to test it*/
  if(root->left !=NULL)
  {
    freeTree(root->left);
  } 
  if(root->right !=NULL)
  {
    freeTree(root->right);
  } 
  free(root);
  root =NULL;
}

/* Print dfs traversal of a tree in visited order,
   each node on a new line,
   where the node is preceeded by the count */
void dfs(struct TreeNode* root)
{ 
  //needs to search right before it searches left and needs to explicitly 
  //use a stack
  // every time you visit a node, put it on the stack
  // reverse the stack to print them in the order visited
  // need to to print the count before every node printed
  
  struct ListNode* temp = NULL;
  
  int i; 
  printf("in\n");
  dfsHelper(root,temp);
  printf("out of helper\n");
  printList(temp);
  reverseList(&temp);
  // for(i=1; i <= listLength(*temp); i++)
  // {
  //   printf("%d: %d\n",i,popStack(temp));
  // } 
  // freeList(*temp);
}

void dfsHelper(struct TreeNode* root, struct ListNode* stack)
{ 
  printf("here\n");
  stack = pushStack(stack, root->data);
  if(root->right != NULL)
  {

    dfsHelper(root->right,stack);
  } 

  if(root->left != NULL)
  {
    dfsHelper(root->left,stack);
  }

} 
// int main() 
// {
//  return 0;
//  }
 // }